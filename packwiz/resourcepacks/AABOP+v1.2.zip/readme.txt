AntiqueAtlasExtra v1.2

This is simply an old ressourcepack updated to work with a newer versions of MC and AA.

Requirements:
 For Minecraft 1.11.x and 1.12.x
 For AntiqueAtlas 4.5.0+ (<-- This is only avaible for MC 1.12.2)
 
Instructions:
 Make backups.
 Put the AntiqueAtlasExtra zip file into .minecraft/ressourcepacks/
 Put the json files into .minecraft/config/antiqueatlas/


If you have an old version prior 4.5.0 of AntiqueAtlas:
 The file biome_textures_old1.json can be used with earlier versions of AA.
 Copy the file into .minecraft/config/antiqueatlas/
 Remove the "_old1" part in the file name.
 Eventually the IDs need a manual correction.
 

Supported biomes are:
 Vanilla
 Biomes O'Plenty
 Thaumcraft
 Nuclearcraft

Thanks goes to:
 Golgorit for making the original texturepack.
 Earlyshooter for writing a list.


Changelog:
 * Added Nuclearcraft Wasteland (uses a BOP texture)
 * Updated the biome_textures.json to work with AntiqueAtlas 4.5.0+
 * Updated the ressource pack to work with Minecraft 1.11 and 1.12
